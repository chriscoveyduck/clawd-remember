import { MemoryManager } from "./memory.js"
import { readdir, readFile, writeFile, mkdir } from "node:fs/promises"
import { existsSync } from "node:fs"
import { join, resolve } from "node:path"
import { homedir } from "node:os"
import { OllamaEmbedder } from "./embedders/ollama.js"
import { OpenAICompatibleExtractor } from "./extractors/openai.js"
import { GitHubCopilotExtractor } from "./extractors/github-copilot.js"
import { SqliteStorageProvider } from "./storage/sqlite.js"
import type { Embedder, LLMExtractor, Message, PluginConfig, RecallOptions, StorageProvider } from "./types.js"
import { withTimeout } from "./utils.js"

type HookContext = {
  config?: PluginConfig
  logger?: {
    warn?: (...args: unknown[]) => void
  }
  state?: Record<string, unknown>
  input?: string
  prompt?: string
  messages?: Message[]
  conversation?: Message[]
  userId?: string
  sessionId?: string
}

type ToolContext = HookContext

type PluginTool = {
  name: string
  description: string
  parameters: Record<string, unknown>
  execute: (input: Record<string, unknown>, context: ToolContext) => Promise<unknown>
}

type PluginEntry = {
  name: string
  slot: "memory"
  configSchema: Record<string, unknown>
  hooks: {
    before_prompt_build: (context: HookContext) => Promise<HookContext>
    after_agent_turn: (context: HookContext) => Promise<HookContext>
  }
  tools: PluginTool[]
}

type PluginDependencies = {
  createStorageProvider?: (config: PluginConfig) => StorageProvider
  createEmbedder?: (config: PluginConfig) => Embedder
  createExtractor?: (config: PluginConfig) => LLMExtractor
}

import { createRequire } from "node:module"
import { Type } from "@sinclair/typebox"


type DefinePluginEntry = <T>(entry: T) => T

let definePluginEntry: DefinePluginEntry = <T>(entry: T) => entry
try {
  const _require = createRequire(import.meta.url)
  const openclaw = _require("openclaw/plugin-sdk")
  if (typeof (openclaw as { definePluginEntry?: unknown }).definePluginEntry === "function") {
    definePluginEntry = openclaw.definePluginEntry as DefinePluginEntry
  }
} catch {
  // Build and test without the OpenClaw runtime installed.
}

const managers = new Map<string, Promise<MemoryManager>>()

async function getManager(context: HookContext, dependencies: PluginDependencies = {}): Promise<MemoryManager> {
  const config = normalizeConfig(context.config)
  const key = JSON.stringify(config)
  const existing = managers.get(key)
  if (existing) {
    return existing
  }

  const managerPromise = createManager(config, dependencies)
  managers.set(key, managerPromise)
  return managerPromise
}

async function createManager(config: PluginConfig, dependencies: PluginDependencies = {}): Promise<MemoryManager> {
  const storage = (dependencies.createStorageProvider ?? createStorageProvider)(config)
  const embedder = (dependencies.createEmbedder ?? ((currentConfig) => new OllamaEmbedder(currentConfig.embedder.config)))(config)
  const extractor = (dependencies.createExtractor ?? createExtractor)(config)
  const manager = new MemoryManager(storage, embedder, extractor, {
    userId: config.userId,
    sessionId: config.sessionId,
    categories: config.categories,
    topK: config.topK,
  })
  await manager.init()
  return manager
}

function createStorageProvider(config: PluginConfig): SqliteStorageProvider {
  if (config.storage.provider === "sqlite") {
    return new SqliteStorageProvider(config.storage.config)
  }

  throw new Error(`Storage provider ${config.storage.provider} is not implemented yet`)
}

function createExtractor(config: PluginConfig): LLMExtractor {
  if (config.llm.provider === "github-copilot") {
    return new GitHubCopilotExtractor(config.llm.config)
  }
  // default: openai-compatible
  return new OpenAICompatibleExtractor((config.llm as { provider: "openai-compatible"; config: import("./types.js").OpenAICompatibleConfig }).config)
}

function warn(context: HookContext, scope: string, error: unknown): void {
  const logger = context.logger
  const message = error instanceof Error ? error.message : String(error)
  logger?.warn?.(`[clawd-remember] ${scope}: ${message}`)
}

async function safeRun<T>(context: HookContext, scope: string, fn: () => Promise<T>, fallback: T): Promise<T> {
  try {
    return await fn()
  } catch (error) {
    warn(context, scope, error)
    return fallback
  }
}

function getConversation(context: HookContext): Message[] {
  return context.conversation ?? context.messages ?? []
}

/**
 * Parse a session-memory markdown file into Message[] pairs.
 * Handles the format written by OpenClaw's built-in session-memory hook.
 */
function parseSessionMemoryFile(content: string): Message[] {
  const messages: Message[] = []
  const lines = content.split("\n")
  let currentRole: string | null = null
  let currentLines: string[] = []

  const flush = () => {
    if (currentRole && currentLines.length) {
      const text = currentLines.join("\n").trim()
      if (text) messages.push({ role: currentRole, content: text })
    }
    currentLines = []
    currentRole = null
  }

  for (const line of lines) {
    if (line.startsWith("user: ") || line === "user:") {
      flush()
      currentRole = "user"
      const rest = line.slice(6).trim()
      if (rest) currentLines.push(rest)
    } else if (line.startsWith("assistant: ") || line === "assistant:") {
      flush()
      currentRole = "assistant"
      const rest = line.slice(11).trim()
      if (rest) currentLines.push(rest)
    } else if (currentRole) {
      currentLines.push(line)
    }
  }
  flush()
  return messages
}

/**
 * Find session-memory files in the workspace memory dir that haven't been processed yet.
 */
async function findUnprocessedFiles(memoryDir: string, processedLogPath: string): Promise<string[]> {
  const processed = new Set<string>()
  if (existsSync(processedLogPath)) {
    try {
      const raw = await readFile(processedLogPath, "utf-8")
      const parsed = JSON.parse(raw) as { processedFiles?: string[] }
      for (const f of parsed.processedFiles ?? []) processed.add(f)
    } catch { /* ignore parse errors */ }
  }

  let files: string[] = []
  try {
    const entries = await readdir(memoryDir)
    files = entries
      .filter(e => e.endsWith(".md") && !processed.has(e))
      .sort()
  } catch { /* dir missing */ }

  return files.map(f => join(memoryDir, f))
}

async function markProcessed(processedLogPath: string, filenames: string[]): Promise<void> {
  let existing: string[] = []
  if (existsSync(processedLogPath)) {
    try {
      const raw = await readFile(processedLogPath, "utf-8")
      existing = (JSON.parse(raw) as { processedFiles?: string[] }).processedFiles ?? []
    } catch { /* ignore */ }
  }
  const updated = Array.from(new Set([...existing, ...filenames]))
  await mkdir(resolve(processedLogPath, ".."), { recursive: true })
  await writeFile(processedLogPath, JSON.stringify({ processedFiles: updated }, null, 2), "utf-8")
}

function getPromptText(context: HookContext): string {
  return context.prompt ?? context.input ?? ""
}

function formatMemories(memories: Awaited<ReturnType<MemoryManager["recall"]>>): string {
  if (!memories.length) {
    return ""
  }

  return [
    "Relevant memory:",
    ...memories.map((item) => `- ${item.fact.data}`),
  ].join("\n")
}

function normalizeConfig(config?: PluginConfig): PluginConfig {
  const storage = config?.storage?.provider === "mariadb"
    ? {
      provider: "mariadb" as const,
      config: config.storage.config,
    }
    : {
      provider: "sqlite" as const,
      config: config?.storage?.provider === "sqlite"
        ? config.storage.config
        : { path: "~/.openclaw/clawd-remember.db" },
    }

  return {
    storage,
    embedder: {
      provider: "ollama",
      config: {
        url: config?.embedder?.config?.url ?? "http://localhost:11434",
        model: config?.embedder?.config?.model ?? "nomic-embed-text",
        timeoutMs: config?.embedder?.config?.timeoutMs,
      },
    },
    llm: config?.llm?.provider === "github-copilot"
      ? {
          provider: "github-copilot" as const,
          config: {
            model: (config.llm.config as { model?: string }).model,
            tokenPath: (config.llm.config as { tokenPath?: string }).tokenPath,
            timeoutMs: (config.llm.config as { timeoutMs?: number }).timeoutMs,
          },
        }
      : {
          provider: "openai-compatible" as const,
          config: {
            baseURL: (config?.llm?.config as { baseURL?: string } | undefined)?.baseURL ?? "http://localhost:4141/v1",
            model: (config?.llm?.config as { model?: string } | undefined)?.model ?? "gpt-4o-mini",
            apiKey: (config?.llm?.config as { apiKey?: string } | undefined)?.apiKey ?? "dummy",
            timeoutMs: (config?.llm?.config as { timeoutMs?: number } | undefined)?.timeoutMs,
          },
        },
    userId: config?.userId ?? "default",
    sessionId: config?.sessionId,
    autoRecall: config?.autoRecall ?? true,
    autoCapture: config?.autoCapture ?? true,
    topK: config?.topK ?? 10,
    recallTimeout: config?.recallTimeout ?? 10_000,
    captureTimeout: config?.captureTimeout ?? 15_000,
    categories: config?.categories,
  }
}

function createBeforePromptBuild(dependencies: PluginDependencies = {}) {
  return async function handleRecall(context: HookContext): Promise<HookContext> {
  const config = normalizeConfig(context.config)
  if (!config.autoRecall) {
    return context
  }

  return safeRun(context, "before_prompt_build", async () => {
    const prompt = getPromptText(context)
    if (!prompt.trim()) {
      return context
    }

    const manager = await getManager({ ...context, config }, dependencies)
    const memories = await withTimeout(
      manager.recall(prompt, {
        topK: config.topK,
        user_id: context.userId ?? config.userId,
        session_id: context.sessionId ?? config.sessionId,
      }),
      config.recallTimeout ?? 10_000,
      "memory recall",
    )

    const memoryBlock = formatMemories(memories)
    if (!memoryBlock) {
      return context
    }

    return {
      ...context,
      prompt: [memoryBlock, getPromptText(context)].filter(Boolean).join("\n\n"),
      state: {
        ...context.state,
        clawdRememberRecall: memories,
      },
    }
  }, context)
}
}

function createAfterAgentTurn(dependencies: PluginDependencies = {}) {
  return async function handleCapture(context: HookContext): Promise<HookContext> {
  const config = normalizeConfig(context.config)
  if (!config.autoCapture) {
    return context
  }

  return safeRun(context, "after_agent_turn (disk)", async () => {
    // Resolve memory directory: config.diskCapturePath or default workspace memory/
    const workspaceDir = (context as unknown as Record<string, unknown>).workspaceDir as string | undefined
    const rawDiskPath = (config as unknown as Record<string, unknown>).diskCapturePath as string | undefined
    const memoryDir = rawDiskPath
      ? rawDiskPath.replace(/^~/, homedir())
      : join(workspaceDir?.replace(/^~/, homedir()) ?? join(homedir(), ".openclaw", "workspace"), "memory")

    const processedLogPath = join(memoryDir, ".clawd-remember-processed.json")
    const unprocessed = await findUnprocessedFiles(memoryDir, processedLogPath)

    if (!unprocessed.length) {
      // Fallback: try live context conversation (may be empty if allowConversationAccess unavailable)
      const conversation = getConversation(context)
      if (!conversation.length) return context
      const manager = await getManager({ ...context, config }, dependencies)
      await withTimeout(
        manager.capture(conversation, {
          userId: context.userId ?? config.userId,
          sessionId: context.sessionId ?? config.sessionId,
          categories: config.categories,
        }),
        config.captureTimeout ?? 15_000,
        "memory capture (live)",
      )
      return context
    }

    const manager = await getManager({ ...context, config }, dependencies)
    const processedNames: string[] = []

    for (const filePath of unprocessed) {
      try {
        const fileContent = await readFile(filePath, "utf-8")
        const conversation = parseSessionMemoryFile(fileContent)
        if (conversation.length >= 2) {
          await withTimeout(
            manager.capture(conversation, {
              userId: context.userId ?? config.userId,
              sessionId: context.sessionId ?? config.sessionId,
              categories: config.categories,
            }),
            config.captureTimeout ?? 30_000,
            `memory capture (disk: ${filePath})`,
          )
        }
        processedNames.push(filePath.split("/").pop()!)
      } catch (err) {
        // Log but don't fail — skip bad files
        context.logger?.warn?.(`clawd-remember: failed to process ${filePath}:`, err)
      }
    }

    if (processedNames.length) {
      await markProcessed(processedLogPath, processedNames)
    }

    return context
  }, context)
}
}

function createSearchTool(dependencies: PluginDependencies = {}) {
  return async function runSearchTool(input: Record<string, unknown>, context: ToolContext): Promise<unknown> {
  const config = normalizeConfig(context.config)
  return safeRun(context, "memory_search tool", async () => {
    const manager = await getManager({ ...context, config }, dependencies)
    return manager.search(String(input.query ?? ""), {
      topK: typeof input.topK === "number" ? input.topK : config.topK,
      user_id: String(input.userId ?? context.userId ?? config.userId),
      session_id: typeof input.sessionId === "string" ? input.sessionId : context.sessionId ?? config.sessionId,
      categories: Array.isArray(input.categories)
        ? input.categories.filter((item): item is string => typeof item === "string")
        : undefined,
    } satisfies RecallOptions)
  }, [])
}
}

function createAddTool(dependencies: PluginDependencies = {}) {
  return async function runAddTool(input: Record<string, unknown>, context: ToolContext): Promise<unknown> {
  const config = normalizeConfig(context.config)
  return safeRun(context, "memory_add tool", async () => {
    const manager = await getManager({ ...context, config }, dependencies)
    return manager.add(
      String(input.text ?? ""),
      String(input.userId ?? context.userId ?? config.userId),
      typeof input.sessionId === "string" ? input.sessionId : context.sessionId ?? config.sessionId,
      Array.isArray(input.categories)
        ? input.categories.filter((item): item is string => typeof item === "string")
        : config.categories,
    )
  }, null)
}
}

function createDeleteTool(dependencies: PluginDependencies = {}) {
  return async function runDeleteTool(input: Record<string, unknown>, context: ToolContext): Promise<unknown> {
  return safeRun(context, "memory_delete tool", async () => {
    const manager = await getManager(context, dependencies)
    await manager.delete(String(input.id ?? ""))
    return { deleted: true }
  }, { deleted: false })
}
}

export const configSchema = {
  type: "object",
  required: ["storage", "embedder", "llm", "userId"],
  properties: {
    storage: {
      type: "object",
      required: ["provider", "config"],
      properties: {
        provider: { type: "string", enum: ["sqlite", "mariadb"] },
        config: {
          type: "object",
          properties: {
            path: { type: "string" },
            host: { type: "string" },
            port: { type: "number" },
            user: { type: "string" },
            password: { type: "string" },
            database: { type: "string" },
            table: { type: "string" },
          },
          additionalProperties: true,
        },
      },
      additionalProperties: false,
    },
    embedder: {
      type: "object",
      required: ["provider", "config"],
      properties: {
        provider: { type: "string", enum: ["ollama"] },
        config: {
          type: "object",
          required: ["url", "model"],
          properties: {
            url: { type: "string" },
            model: { type: "string" },
            timeoutMs: { type: "number" },
          },
          additionalProperties: false,
        },
      },
      additionalProperties: false,
    },
    llm: {
      type: "object",
      required: ["provider", "config"],
      properties: {
        provider: { type: "string", enum: ["openai-compatible", "github-copilot"] },
        config: {
          type: "object",
          properties: {
            baseURL: { type: "string" },
            model: { type: "string" },
            apiKey: { type: "string" },
            tokenPath: { type: "string" },
            timeoutMs: { type: "number" },
          },
          additionalProperties: true,
        },
      },
      additionalProperties: false,
    },
    userId: { type: "string" },
    sessionId: { type: "string" },
    autoRecall: { type: "boolean" },
    autoCapture: { type: "boolean" },
    topK: { type: "number" },
    recallTimeout: { type: "number" },
    captureTimeout: { type: "number" },
    categories: {
      type: "array",
      items: { type: "string" },
    },
    diskCapturePath: { type: "string" },
  },
  additionalProperties: true,
} as const

export function createPlugin(dependencies: PluginDependencies = {}): PluginEntry {
  return {
    name: "clawd-remember",
    slot: "memory",
    configSchema,
    hooks: {
      before_prompt_build: createBeforePromptBuild(dependencies),
      after_agent_turn: createAfterAgentTurn(dependencies),
    },
    tools: [
      {
        name: "memory_search",
        description: "Search stored memories for the current user.",
        parameters: {
          type: "object",
          required: ["query"],
          properties: {
            query: { type: "string" },
            topK: { type: "number" },
            userId: { type: "string" },
            sessionId: { type: "string" },
            categories: { type: "array", items: { type: "string" } },
          },
        },
        execute: createSearchTool(dependencies),
      },
      {
        name: "memory_add",
        description: "Persist a new memory fact.",
        parameters: {
          type: "object",
          required: ["text"],
          properties: {
            text: { type: "string" },
            userId: { type: "string" },
            sessionId: { type: "string" },
            categories: { type: "array", items: { type: "string" } },
          },
        },
        execute: createAddTool(dependencies),
      },
      {
        name: "memory_delete",
        description: "Delete a memory by id.",
        parameters: {
          type: "object",
          required: ["id"],
          properties: {
            id: { type: "string" },
          },
        },
        execute: createDeleteTool(dependencies),
      },
    ],
  }
}

// eslint-disable-next-line @typescript-eslint/no-explicit-any
type PluginApi = any

export default definePluginEntry({
  id: "clawd-remember",
  name: "clawd-remember",
  description: "Disk-based session memory capture with SQLite + Ollama",
  kind: "memory",
  configSchema,
  register(api: PluginApi) {
    const config = normalizeConfig(api.pluginConfig as PluginConfig | undefined)

    // Hook: inject memories before prompt build
    api.on("before_prompt_build", async (event: unknown) => {
      if (!config.autoRecall) return undefined
      const ev = event as { prompt?: string; messages?: Message[]; userId?: string; sessionId?: string }
      const prompt = ev.prompt ?? ""
      if (!prompt.trim()) return undefined

      try {
        const key = JSON.stringify(config)
        let managerPromise = managers.get(key)
        if (!managerPromise) {
          managerPromise = createManager(config)
          managers.set(key, managerPromise)
        }
        const manager = await managerPromise
        const memories = await withTimeout(
          manager.recall(prompt, {
            topK: config.topK,
            user_id: ev.userId ?? config.userId,
            session_id: ev.sessionId ?? config.sessionId,
          }),
          config.recallTimeout ?? 10_000,
          "memory recall",
        )
        const memoryBlock = formatMemories(memories)
        if (!memoryBlock) return undefined
        return { appendSystemContext: memoryBlock }
      } catch (err) {
        console.warn("[clawd-remember] before_prompt_build error:", err)
        return undefined
      }
    })

    // Tool: memory_search
    api.registerTool({
      name: "memory_search",
      description: "Search stored memories for the current user.",
      parameters: Type.Object({
        query: Type.String({ description: "Search query" }),
        topK: Type.Optional(Type.Number({ description: "Number of results" })),
        userId: Type.Optional(Type.String()),
        sessionId: Type.Optional(Type.String()),
      }),
      async execute(_toolCallId: string, params: Record<string, unknown>) {
        try {
          const key = JSON.stringify(config)
          let managerPromise = managers.get(key)
          if (!managerPromise) {
            managerPromise = createManager(config)
            managers.set(key, managerPromise)
          }
          const manager = await managerPromise
          const results = await manager.search(String(params.query ?? ""), {
            topK: typeof params.topK === "number" ? params.topK : config.topK,
            user_id: String(params.userId ?? config.userId),
            session_id: typeof params.sessionId === "string" ? params.sessionId : config.sessionId,
          })
          return { content: [{ type: "text", text: JSON.stringify(results) }] }
        } catch (err) {
          return { content: [{ type: "text", text: `Error: ${err}` }] }
        }
      },
    })

    // Tool: memory_add
    api.registerTool({
      name: "memory_add",
      description: "Persist a new memory fact.",
      parameters: Type.Object({
        text: Type.String({ description: "Fact to remember" }),
        userId: Type.Optional(Type.String()),
      }),
      async execute(_toolCallId: string, params: Record<string, unknown>) {
        try {
          const key = JSON.stringify(config)
          let managerPromise = managers.get(key)
          if (!managerPromise) {
            managerPromise = createManager(config)
            managers.set(key, managerPromise)
          }
          const manager = await managerPromise
          await manager.add(
            String(params.text ?? ""),
            String(params.userId ?? config.userId),
            config.sessionId,
            config.categories,
          )
          return { content: [{ type: "text", text: "stored" }] }
        } catch (err) {
          return { content: [{ type: "text", text: `Error: ${err}` }] }
        }
      },
    })

    // Tool: memory_delete
    api.registerTool({
      name: "memory_delete",
      description: "Delete a memory by id.",
      parameters: Type.Object({
        id: Type.String({ description: "Memory ID to delete" }),
      }),
      async execute(_toolCallId: string, params: Record<string, unknown>) {
        try {
          const key = JSON.stringify(config)
          let managerPromise = managers.get(key)
          if (!managerPromise) {
            managerPromise = createManager(config)
            managers.set(key, managerPromise)
          }
          const manager = await managerPromise
          await manager.delete(String(params.id ?? ""))
          return { content: [{ type: "text", text: "deleted" }] }
        } catch (err) {
          return { content: [{ type: "text", text: `Error: ${err}` }] }
        }
      },
    })
  },
})

export * from "./types.js"
export * from "./memory.js"
export * from "./storage/sqlite.js"
export * from "./embedders/ollama.js"
export * from "./extractors/openai.js"

export * from "./extractors/github-copilot.js"
